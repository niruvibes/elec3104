
clc

%%functions
function h_out = cropStoredImpulse(h_in, maxLen)
    L = length(h_in);

    if L >= maxLen
        h_out = h_in(1:maxLen);
    else
        h_out = [h_in; zeros(maxLen - L, 1)];
    end
end

%% Step 1
% Constants
DeltaX = ((2.9985-0.02)/(128-1));
Fs = 16000;

n = (1:128)';  

% formulas
fp = 8000 .* 10.^(-0.667 .* (128 - n + 1) .* DeltaX);
Qp = 5 + ((5 / (max(n) - 1)) .* (n - 1));
BWp = fp ./ Qp;
thetap = 2 .* pi .* fp ./ Fs;
rp = 1 - (BWp ./ Fs) .* pi;
b1 = 2 .* rp .* cos(thetap);
b2 = rp .^ 2;

% table
FilterTable = table(n, fp, Qp, BWp, thetap, rp, b1, b2, ...
    'VariableNames', {'Filter_no','fp','Qp','BWp','thetap','rp','b1','b2'});

disp(FilterTable)

%% Step 2

numFilters = height(FilterTable);
impResIIR = cell(numFilters,1);
freqRes = cell(numFilters,1);
freqVectors = cell(numFilters,1);

freqSelection = cell(2,1);

for k = 1:numFilters
    b1k = FilterTable.b1(k);
    b2k = FilterTable.b2(k);
    
    % (1 - z^-2) / (1 - b1*z^-1 + b2*z^-2)
    b = [1 0 -1];
    a = [1 -b1k b2k];
    
    % truncation
    len = 160;
    
    [h, t] = impz(b, a);
    impResIIR{k} = h;

    [H,f] = freqz(b,a, len, Fs);
    freqRes{k} = H;
    freqVectors{k} = f;
 end

figure
subplot(2,3,1)
plot(impResIIR{45})
title("IIR Impulse Response (Filter 45)")
xlim([0 200])
xlabel("Sample number")

subplot(2,3,4)
plot(impResIIR{65})
title("IIR Impulse Response (Filter 65)")
xlim([0 200])
xlabel("Sample number")

subplot(2,3,2)
plot(freqVectors{100}, 20*log10(abs(freqRes{100})))
title("Mag Response Filter 100")
xlabel("Frequency (Hz)")
ylabel("Magnitude (dB)")

subplot(2,3,5)
plot(freqVectors{100}, unwrap(angle(freqRes{100})))
title("Phase Response Filter 100")
xlabel("Frequency (Hz)")
ylabel("Phase (Rads)")

subplot(2,3,[3,6])
plot(freqVectors{45}, 20*log10(abs(freqz(cropStoredImpulse(impResIIR{45},160),1, len, Fs))))
hold on
plot(freqVectors{45}, 20*log10(abs(freqRes{45})))
plot(freqVectors{65}, 20*log10(abs(freqz(cropStoredImpulse(impResIIR{65},160),1, len, Fs))))
plot(freqVectors{65}, 20*log10(abs(freqRes{65})))
hold off
title("FIR vs IIR (Filters 45 & 65)")
xlabel("Frequency (Hz)")
ylabel("Magnitude (dB)")

%% Step 3

filterNo = 72;
len = 160;

HIIR = freqRes{filterNo};
fIIR = freqVectors{filterNo};

magIIR = 20*log10(abs(HIIR));
magIIR = magIIR - max(magIIR);  % normalize

% fir
hFULL = impResIIR{filterNo};
hTruncated = cropStoredImpulse(hFULL, len);

[HFIR, fFIR] = freqz(hTruncated, 1, len, Fs);
magFIR = 20*log10(abs(HFIR));
magFIR = magFIR - max(magFIR);

% Plot
figure
plot(fIIR, magIIR, 'LineWidth', 1.5)
hold on
plot(fFIR, magFIR, '--', 'LineWidth', 1.5)
grid on
xlabel("Frequency (Hz)")
ylabel("Magnitude (dB)")
title("IIR vs FIR (Truncated) — Filter " + filterNo)
legend("IIR", "FIR-Truncated")

% multiple plotes
selectedFilters = round(linspace(1, 127, 10));

figure;
hold on;

for idx = 1:length(selectedFilters)
    k = selectedFilters(idx);

    % Use stored IIR freq response
    Hk = freqRes{k};
    fk = freqVectors{k};

    % Normalize to 0 dB
    mag = 20*log10(abs(Hk));
    mag = mag - max(mag);

    plot(fk, mag, 'LineWidth', 1.2);
end

grid on;
xlabel("Frequency (Hz)");
ylabel("Magnitude (dB)");
title("Magnitude Responses of 10 IIR Filters (Normalised)");
legend(cellstr(string(selectedFilters)));
hold off;
ylim([-15, 0])

%% audio magic

function [speechSyn, musicSync, hBank, xSpeech, xMusic] = runFilterBank(FilterTable, M)
    Fs = 16000;
    
    speechFile = 'speech.wav';
    musicFile  = 'music.wav';

    % load audio
    [xSpeech, speechFs] = audioread(speechFile);
    [xMusic,  musicFs] = audioread(musicFile);
    if speechFs ~= Fs || musicFs ~= Fs
        error('Audio files must be sampled at 16 kHz');
    end

    % convert to mono but i dont think this is needed
    if size(xSpeech,2) > 1, xSpeech = mean(xSpeech,2); end
    if size(xMusic,2)  > 1, xMusic  = mean(xMusic,2);  end

    % bank
    numFilters = height(FilterTable);
    hBank = cell(numFilters,1);
    
    for k = 1:numFilters
        b1k = FilterTable.b1(k);
        b2k = FilterTable.b2(k);
        b = [1 0 -1];
        a = [1 -b1k b2k];
    
        % compute long IIR impulse response and modify to length M
        hFULL = impz(b, a, 5000);
        h_tr = cropStoredImpulse(hFULL, M);

        %uncommment this for gain thingy
        % [HTmp2, fTmp2] = freqz(h_tr, 1, 512);
        % h_tr = h_tr / max(abs(HTmp2));
    
        hBank{k} = h_tr;
    end

    % filter outputs
    y_speech = cell(numFilters,1);
    y_music  = cell(numFilters,1);

    % filter each signal
    for k = 1:numFilters
        hk = hBank{k};
    
        y_speech{k} = conv(xSpeech, hk, 'same');
        y_music{k}  = conv(xMusic,  hk, 'same');
    end
    
    % sum the bands
    speech_syn = zeros(size(xSpeech));
    music_syn  = zeros(size(xMusic));
    
    for k = 1:numFilters
        speech_syn = speech_syn + y_speech{k};
        music_syn  = music_syn  + y_music{k};
    end

    % normalise
    speechSyn = speech_syn ./ max(abs(speech_syn));
    musicSync  = music_syn  ./ max(abs(music_syn));

    % save
    % audiowrite("speech_synthesized.wav", speech_syn, Fs);
    % audiowrite("music_synthesized.wav",  music_syn, Fs);
end

[speech160, music160, hBank, xSpeech, xMusic] = runFilterBank(FilterTable, 160);
[speech300, music300] = runFilterBank(FilterTable, 300);


figure
subplot(2,3,1)
plot(xSpeech)
title("speech (og)")

subplot(2,3,2)
plot(speech160)
title("speech_syn (160)")

subplot(2,3,3)
plot(speech300)
title("speech_syn (300)")

subplot(2,3,4)
plot(xMusic)
title("music (og)")

subplot(2,3,5)
plot(music160)
title("music_syn (160)")

subplot(2,3,6)
plot(music300)
title("music_syn (300)")

% disp("og speech");
% soundsc(xSpeech, Fs);
% pause(length(xSpeech)/Fs + 1);
% 
% disp("reconstructed speech 160");
% soundsc(speech160, Fs);
% pause(length(xSpeech)/Fs + 1);
% 
% disp("reconstructed speech 300");
% soundsc(speech300, Fs);
% pause(length(xSpeech)/Fs + 1);

% disp("og music");
% soundsc(x_music, Fs);
% pause(length(x_music)/Fs + 1);
% 
% disp("reconstructed music 160");
% soundsc(music160, Fs);
% pause(length(x_music)/Fs + 1);
% 
% disp("reconstructed music 300");
% soundsc(music300, Fs);
% pause(length(x_music)/Fs + 1);

% speech
% since there ar eonly 160samples, the resolution is lower
% truncation of IIR causes smoothening
% high frequency waves become weaker

% music
% High-frequency details softer
% sounds a bit underwater
% lows and mids about the same

% 300 vs 160
% there is little to no difference audibly when using 300 taps as opposed
% to 160


%% Step 4

len = 160;
numFilters = height(FilterTable);
gBank = cell(numFilters,1);
ABank = cell(numFilters,1);

for k = 1:numFilters
    h = cropStoredImpulse(hBank{k}, len);

    % g[n] = h[L - n]
    g = flipud(h);

    gBank{k} = g;
    ABank{k} = conv(h, g);
end

% symmetry
filterNo = 100;

h = hBank{filterNo};
h = cropStoredImpulse(h,len);
g = gBank{filterNo};
A = ABank{filterNo};

function output = normalise(wave)
    output = 20*log10(abs(wave));
    output = output - max(output);
end

figure;
% symmtery
subplot(3,2,[1, 2]);
plot(A, "LineWidth", 1.4); hold on;
xline(len, "--r", "Center tap (n = 160)", LabelVerticalAlignment="bottom");
xlabel("Sample Index"); ylabel("Amplitude");
grid on;

% mag
subplot(3,2,3);
[H,f] = freqz(h,1,1024,Fs);
plot(f, normalise(H)); 
xlabel('Frequency (Hz)'); 
ylabel('Magnitude (dB)');
title("Magnitude Response (Analysis)");
ylim([-50 0]);
xlim([0 8000]);
grid on;


subplot(3,2,5);
[HA, fA] = freqz(A,1,1024,Fs);
plot(fA, normalise(HA));
title("Magnitude Response (Combined)");
xlabel('Frequency (Hz)'); 
ylabel('Magnitude (dB)');
ylim([-50 0]);
xlim([0 8000]);
grid on;

% phase
subplot(3,2,4);
plot(f, unwrap(angle(H)), 'LineWidth', 1.4); hold on;
xlabel('Frequency (Hz)'); 
ylabel('Phase (rad)');
title("Phase Response (Analysis)");
ylim([-2 4]);
grid on;


subplot(3,2,6);
plot(fA, unwrap(angle(HA)));
xlabel('Frequency (Hz)'); 
ylabel('Phase (rad)');
title("Phase Response (Combined)");
grid on;

figure;
hold on;
ylim([-15 0]);
xlim([0 8]);

filterIndices = round(linspace(1, numFilters, 10));
for i = 1:10
    k = filterIndices(i);
    g = gBank{k};
    [G,f] = freqz(g,1,1024,Fs);

    plot(f/1000, normalise(G));
end

xlabel("Frequency (Hz)");
ylabel("Magnitude (dB)");
title("Magnitude Responses of 10 synthesis Filters (Normalised)");
ylim([-15 0])

%% Step 5: Implementation
len = 160;
filterNo = 72;

% magnitude response of analysis
h = hBank{filterNo};                   
[H, hf] = freqz(h, 1, len, Fs);

% magnitude response of synthesis filter
g = gBank{filterNo};                  
[G, gf] = freqz(g, 1, len, Fs);

figure
plot(h, 'b', 'DisplayName', 'Analysis (h)')
hold on
plot(g, 'r', 'DisplayName', 'Synthesis (g)')
hold off
legend('show')
title('Impulse Responses of Analysis and Synthesis Filters')
xlabel('Sample Index')
ylabel('Amplitude')

%160

speechFile = 'speech.wav';
musicFile  = 'music.wav';

% load audio exactly same as your runFilterBank
[xSpeech, speechFs] = audioread(speechFile);
[xMusic,  musicFs] = audioread(musicFile);

if speechFs ~= Fs || musicFs ~= Fs
    error('Audio files must be sampled at 16 kHz');
end

% convert to mono (same as before)
if size(xSpeech,2) > 1, xSpeech = mean(xSpeech,2); end
if size(xMusic,2)  > 1, xMusic  = mean(xMusic,2);  end

numFilters = height(FilterTable);

% allocate outputs
speechCombined = zeros(size(xSpeech));
musicCombined  = zeros(size(xMusic));

for k = 1:numFilters
    Ak = ABank{k};

    % filter each signal through the combined filter
    speechCombined = speechCombined + conv(xSpeech, Ak, 'same');
    musicCombined  = musicCombined  + conv(xMusic,  Ak, 'same');
end

% normalise
speechCombined = speechCombined ./ max(abs(speechCombined));
musicCombined  = musicCombined  ./ max(abs(musicCombined));

%300
M = 300;

[speech300_full, music300_full, hBank300, xSpeech, xMusic] = runFilterBank(FilterTable, M);
numFilters = height(FilterTable);

gBank300 = cell(numFilters,1);
ABank300 = cell(numFilters,1);

for k = 1:numFilters
    h = cropStoredImpulse(hBank300{k}, M);
    g = flipud(h);

    gBank300{k} = g;
    ABank300{k} = conv(h, g);
end

speechCombined300 = zeros(size(xSpeech));
musicCombined300  = zeros(size(xMusic));

for k = 1:numFilters
    Ak = ABank300{k};
    speechCombined300 = speechCombined300 + conv(xSpeech, Ak, 'same');
    musicCombined300  = musicCombined300  + conv(xMusic,  Ak, 'same');
end

% normalise
speechCombined300 = speechCombined300 ./ max(abs(speechCombined300));
musicCombined300  = musicCombined300  ./ max(abs(musicCombined300));

% PLAYBACK
% disp("Original speech");
% soundsc(xSpeech, Fs);
% pause(length(xSpeech)/Fs + 1);
% 
% disp("Reconstructed speech (160)");
% soundsc(speechCombined, Fs);
% pause(length(xSpeech)/Fs + 1);
% 
% disp("Reconstructed speech (300)");
% soundsc(speechCombined300, Fs);
% pause(length(xSpeech)/Fs + 1);
% 
% disp("Original music");
% soundsc(xMusic, Fs);
% pause(length(xMusic)/Fs + 1);
% 
% disp("Reconstructed music (160)");
% soundsc(musicCombined, Fs);
% pause(length(xMusic)/Fs + 1);
% 
% disp("Reconstructed music (300)");
% soundsc(musicCombined300, Fs);
% pause(length(xMusic)/Fs + 1);

% optional plots
figure;
subplot(2,2,1); plot(speechCombined300); title("Reconstructed Speech (300)");
subplot(2,2,2); plot(musicCombined300);  title("Reconstructed Music (300)");
subplot(2,2,3); plot(speechCombined); title("Reconstructed Speech (160)");
subplot(2,2,4); plot(musicCombined);  title("Reconstructed Music (160)");


%% Step 6
frame_duration = 0.02; % 20 ms
Fs = 16000;
frameLen = round(frame_duration * Fs);
numFilters = height(FilterTable);
M = 160; % FIR length

noisy_files = {'noise10db.wav', 'noise0db.wav'};
for noisySeg = 1:length(noisy_files)
    noisyFile = noisy_files{noisySeg};
    [xNoisy, fsNoisy] = audioread(noisyFile);
    if fsNoisy ~= Fs
        error('Noisy file must be sampled at 16 kHz');
    end
    if size(xNoisy,2) > 1, xNoisy = mean(xNoisy,2); end

    % pad
    num_frames = ceil(length(xNoisy)/frameLen);
    x_noisy_padded = [xNoisy; zeros(num_frames*frameLen - length(xNoisy),1)];

    % filters
    hBank = cell(numFilters,1);
    for k = 1:numFilters
        b1k = FilterTable.b1(k);
        b2k = FilterTable.b2(k);
        b = [1 0 -1];
        a = [1 -b1k b2k];
        hFULL = impz(b, a, 5000);
        if length(hFULL) < M
            h_tr = [hFULL; zeros(M-length(hFULL),1)];
        else
            h_tr = hFULL(1:M);
        end
        hBank{k} = h_tr;
    end

    subbands = zeros(numFilters, num_frames*frameLen);
    for k = 1:numFilters
        hk = hBank{k};
        subbands(k,:) = conv(x_noisy_padded, hk, 'same');
    end

    % estimate noise pwoer
    noise_frames = 10;
    sigma_w2 = zeros(numFilters,1);
    for k = 1:numFilters
        noise_energy = 0;
        for f = 1:noise_frames
            idx = (f-1)*frameLen+1 : f*frameLen;
            noise_energy = noise_energy + sum(subbands(k,idx).^2);
        end
        sigma_w2(k) = noise_energy / (noise_frames*frameLen);
    end

    % denoising by frame
    mu = 1;
    subbandsDenoised = zeros(size(subbands));
    for f = 1:num_frames
        idx = (f-1)*frameLen+1 : f*frameLen;
        for k = 1:numFilters
            frame = subbands(k,idx);
            sigmaS2 = mean(frame.^2);

            sigmaSpeech2 = max(sigmaS2 - sigma_w2(k), 0);

            Km = sigmaSpeech2 / (sigmaSpeech2 + mu*sigma_w2(k) + eps);

            subbandsDenoised(k,idx) = Km * frame;
        end
    end

    % reconstruct denoised signal
    xDenoised = sum(subbandsDenoised,1)';
    xDenoised = xDenoised(1:length(xNoisy)); % remove padding
    xDenoised = xDenoised / max(abs(xDenoised));

    %noisy first
    soundsc(xNoisy, Fs);
    pause(length(xNoisy)/Fs + 1);
    % denoised second
    soundsc(xDenoised, Fs);
    pause(length(xNoisy)/Fs + 1);

    % plot
    t = (0:length(xNoisy)-1)/Fs;
    figure;
    subplot(2,1,1); plot(t, xNoisy); 
    title(['Noisy Speech: ' noisyFile]); 
    xlabel('Time (s)'); 
    ylabel('Amplitude');


    subplot(2,1,2); plot(t, xDenoised); 
    title('Denoised Speech'); 
    xlabel('Time (s)'); 
    ylabel('Amplitude');
end