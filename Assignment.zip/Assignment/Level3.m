clear
clc

%% function
function output = normalise(wave)
    output = 20*log10(abs(wave));
    output = output - max(output);
end

%% main
Fs = 16000
N = 128
DeltaX = ((2.9985-0.02)/(N-1));
filter_index = (1:128)';  

% formulas
fp = 8000 .* 10.^(-0.667 .* (128 - filter_index + 1) .* DeltaX);
Qp = 5 + ((5 / (max(filter_index) - 1)) .* (filter_index - 1));
BWp = fp ./ Qp;
thetap = 2 .* pi .* fp ./ Fs;
rp = 1 - (BWp ./ Fs) .* pi;
b1 = 2 .* rp .* cos(thetap);
b2 = rp .^ 2;

iirBank = zeros(3, N);
for k = 1:N
    iirBank(:, k) = [1; -b1(k); b2(k)];
end

b_bp = [1];
kGain = zeros(N,1);
LTest = Fs;
n_test = 0:LTest-1;
for k = 1:N
    testSig = sin(2*pi*fp(k)*n_test/Fs);
    
    a = iirBank(:,k).';
    y = filter(b_bp, a, testSig); 
    
    kGain(k) = 1 / max(abs(y));
end

%% sum of sinusoidal components
L = Fs * 1;
n = 0:(L-1);
freq_60 = fp(60); 
freq_100 = fp(100);
x = sin(2*pi*freq_60*n/Fs) + sin(2*pi*freq_100*n/Fs);

% filter through all channels
s = zeros(L, N);
for k = 1:N
    a = iirBank(:, k).'; % [1 -b1 b2]
    y = filter(b_bp, a, x);
    s(:,k) = kGain(k) * y;
end

% spat diff
d = s(:,1:end-1) - s(:,2:end);
e = d(:,1:end-1) - d(:,2:end);

% first hair cell model
fc = 30;
c0 = exp(-2*pi*fc/Fs);
eRectified = max(e, 0);
v = zeros(size(eRectified));
for n = 2:size(eRectified,1)
    v(n,:) = (1 - c0) * eRectified(n,:) + c0 * v(n-1,:);
end
step = round(0.016 * Fs); % 256
vSampled = v(1:step:end, :); % downsampled

%second hair cell model
frame = round(0.016 * Fs); % 256
numFrames = floor(size(eRectified,1) / frame);
q = zeros(numFrames, size(eRectified,2)); % raw energy

for k = 1:numFrames
    idx_start = (k-1)*frame + 1;
    idx_end   = k*frame;

    frame_block = eRectified(idx_start:idx_end, :);
    q(k,:) = sum(frame_block, 1);
end

fc = 30;
alpha = exp(-2*pi*fc*(frame/Fs));
p = zeros(numFrames, size(eRectified,2)); % p[st filter energy
p(1,:) = q(1,:);
for k = 2:numFrames
    p(k,:) = alpha * p(k-1,:) + (1 - alpha) * q(k,:);
end

%%plotting
figure;
t_time = round(0.1 * Fs);
frame_time = 0.016; 
frame_index = round(0.1 / frame_time);

subplot(5,1,1)
plot(1:N, s(t_time,:));
title('Displacement before spatial differentiation s_1[n]...s_N[n]');
xlim([1 N]);
xlabel("displacement")

subplot(5,1,2)
plot(1:N-1, d(t_time,:));
title('Displacement after first spatial differentiation d_1[n]...d_N[n]');
xlim([1 N]);
xlabel("displacement")

subplot(5,1,3)
plot(1:N-2, e(t_time,:));
title('Displacement after second spatial differentiation e_1[n]...e_N[n]');
xlim([1 N]);
xlabel("displacement")

% First hair cell output (Model 1)
subplot(5,1,4)
plot(1:N-2, v(t_time, :))

ylabel('Energy');
title('Inner hair cell output 1 E_1[n]...E_N[n]');
xlim([1 N]);
grid on;

% Second hair cell output (Model 2)
subplot(5,1,5)
plot(1:N-2, p(frame_index, :))
xlabel('Filter index');
ylabel('Energy');
title('Inner hair cell output 2 E_1[n]...E_N[n]');
xlim([1 N]);
grid on;
%% plotting the before and after spat

k = 84;
a = iirBank(:, k).'; % denominator
[H, w] = freqz(b_bp, a, 4096, Fs);

a_next = iirBank(:, k+1).';
[HNext, ~] = freqz(b_bp, a_next, 4096, Fs);

D = H - HNext; % first spatial diff

aNext2 = iirBank(:, k+2).';
[HNext2, ~] = freqz(b_bp, aNext2, 4096, Fs);

DNext = HNext - HNext2;
E = D - DNext; %second

figure;
plot(w, normalise(H)); hold on;
plot(w, normalise(D), '--');
plot(w, normalise(E), '-.');

[~, idxH] = max(normalise(H));
[~, idxD] = max(normalise(D));
[~, idxE] = max(normalise(E));
baseline = -40;

line([w(idxH) w(idxH)], [baseline normalise(H(idxH))], 'Color', '#268cdd', 'LineStyle', ':');
line([w(idxD) w(idxD)], [baseline normalise(D(idxD))], 'Color', '#f57729', 'LineStyle', ':');
line([w(idxE) w(idxE)], [baseline normalise(E(idxE))], 'Color', '#ffe864', 'LineStyle', ':');

grid on;
xlabel("Frequency (Hz)");
ylabel("Magnitude (dB)");
legend("s_m[n]", "d_m[n]", "e_m[n]");
title("Magnitude Response of Filter 84 Before/After Spatial Differentiation");
ylim([-40, 0]);
xlim([1000, 2500]);

%% final implementation
L = 1500;
n = 0:L-1;

freqs = [fp(10) fp(20) fp(45) fp(70) fp(80) fp(120)]; 
x = zeros(1,L);
for i = 1:length(freqs)
    x = x + sin(2*pi*freqs(i)*n/Fs);
end

% gain calibrate
kGain = zeros(N,1);

LTest = Fs * 1;
nTest = 0:(LTest-1);

for m = 1:N
    test_sig = sin(2*pi*fp(m)*nTest/Fs);
    a = iirBank(:,m).';
    y = filter(b_bp, a, test_sig);
    kGain(m) = 1 / max(abs(y));
end

L = 1500;
n = 0:L-1;
freqs = [300 700 1200 2000 3000 5000];

x = zeros(1,L);
for i = 1:length(freqs)
    x = x + sin(2*pi*freqs(i)*n/Fs);
end

s = zeros(L, N);
for m = 1:N
    a = iirBank(:,m).';
    s(:,m) = kGain(m) * filter(b_bp, a, x);
end

d = s(:,1:end-1) - s(:,2:end);
e = d(:,1:end-1) - d(:,2:end);

%model 1
fc = 30;
c0 = exp(-2*pi*fc/Fs);

eRectified = max(e, 0);
v1 = zeros(size(eRectified));

for i = 2:L
    v1(i,:) = (1-c0)*eRectified(i,:) + c0*v1(i-1,:);
end

%model2
alpha = 0.01;
v1_sat = v1 ./ (1 + alpha * v1);

v2 = zeros(size(v1));
for n = 2:L
    v2(n,:) = (1-c0)*v1_sat(n,:) + c0*v2(n-1,:);
end

%grpahing
step = round(0.016 * Fs);
frame = 2;

vS1 = v1(1:step:end, :);
figure;
plot(normalise(vS1(frame,:)), 'LineWidth', 1.5);
xlabel("Filter number");
ylabel("Energy (dB)");
title("Spectrum analyser output (Hair Cell Model 1)");
grid on;

vS2 = v2(1:step:end, :);
figure;
plot(normalise(vS2(frame,:)), 'LineWidth', 1.5);
xlabel('Filter number');
ylabel('Energy (dB)');
title('Spectrum analyser output (Hair Cell Model 2)');
grid on;

X = fft(x);
f = (0:L-1) * (Fs/L);
figure;
plot(f(1:L/2), abs(X(1:L/2)), 'LineWidth', 1.5);
xlabel("Frequency (Hz)");
ylabel("Magnitude");
title("FFT of six-tone input signal");
grid on;
